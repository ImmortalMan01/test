export interface OpenAIMessage {
    role: string;
    content: string;
}