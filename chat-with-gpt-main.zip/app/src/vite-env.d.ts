/// <reference types="vite-plugin-comlink/client" />
/// <reference types="vite-plugin-pwa/client" />