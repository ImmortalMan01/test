import SettingsTab from "./tab";

export default function SpeechOptionsTab() {
    return <SettingsTab name="speech" />
}